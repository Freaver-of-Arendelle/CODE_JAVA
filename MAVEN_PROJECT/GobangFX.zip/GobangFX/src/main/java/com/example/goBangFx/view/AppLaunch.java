package com.example.goBangFx.view;

import javafx.application.Application;

/**
 * @author Freaver
 * @date 10/17/2021
 * @time 14:34
 */
public class AppLaunch {
    public static void main(String[] args) {
        Application.launch(LoginApp.class, args);
    }
}
