package com.example.goBangFx.model.bean;

// TODO: 10/15/2021  
public class Admin extends User{

    public Admin(String name, String password) {
        super(name, password, true);
    }
}
