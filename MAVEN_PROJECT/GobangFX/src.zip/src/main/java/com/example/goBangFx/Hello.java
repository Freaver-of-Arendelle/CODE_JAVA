package com.example.goBangFx;

/**
 * @author Freaver
 * @date 10/14/2021
 * @time 10:53
 */
public class Hello {
}
