package com.example.goBangFx.model.bean;

// TODO: 10/15/2021
public class OrdinaryUser extends User{
    public OrdinaryUser(String name, String password) {
        super(name, password, false);
    }
}
