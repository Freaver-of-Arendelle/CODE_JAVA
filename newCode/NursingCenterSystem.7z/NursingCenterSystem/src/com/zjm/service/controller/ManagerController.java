package com.zjm.service.controller;

import com.zjm.model.Manager;



public interface ManagerController {
	public abstract Boolean login(Manager manager);
}
