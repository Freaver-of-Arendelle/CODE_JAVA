/**
 * @Author: Freaver
 * @Date: 4/9/2021  18:17
 */
public interface SalesFormatter {
    public String formatSales(Sales sales);
}
